package cmom.han.testbt.testTask;

import android.content.ComponentName;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button mBnt_ForSingleTask, mBnt_ForAllowTaskRep;
    TextView mTV_Main;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mBnt_ForSingleTask = findViewById(R.id.mBnt_ForSingleTask);
        mBnt_ForAllowTaskRep = findViewById(R.id.mBnt_ForAllowTaskRep);
        mTV_Main = findViewById(R.id.mTV_Main);

        mBnt_ForSingleTask.setOnClickListener(this);
        mBnt_ForAllowTaskRep.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        Intent intent = new Intent();
        switch (v.getId()) {
            case R.id.mBnt_ForSingleTask:
                //跳转androidreview应用SingleToak页面的按钮方法

                ComponentName cnForSingleTask = new ComponentName(
                        "com.hdd.androidreview",
                        "com.hdd.androidreview.Patterm.SingleTaskActivity");
                intent.setComponent(cnForSingleTask);
                break;
            case R.id.mBnt_ForAllowTaskRep:
                //跳转androidreview应用stanbar页面的按钮方法

                intent.setAction("com.hdd.androidreview.PattermActivity");
                ComponentName cnForAllowTaskRep = new ComponentName(
                        "com.hdd.androidreview",
                        "com.hdd.androidreview.Patterm.PattermActivity");
                intent.setComponent(cnForAllowTaskRep);

                break;
        }
        startActivity(intent);

    }
}
